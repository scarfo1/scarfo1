<!DOCTYPE html>
<html lang="es">
<head>
    <title>vila pasteleria</title>
</head>
<body>
<nav class="menu">

 <ul>
	<li> <a href="producto.php">Inicio </a></li>
	<li> <a href="nosotros.php">Nosotros </a></li>
	<li> <a href="contacto.php">Contacto </a></li>
 </ul>

</nav>    
<h1>productos</h1>
    <h3>rolls salados y dulces 250$</h3>
    <img src="roll.png"width="300">
    <img src="roll2.png"width="300">
    <img src="roll3.png"width="300">
    <img src="roll4.png"width="300">
   <hr>
   <h3>media docena de cookies 400$ </h3> 
   <img src="c.png"width="300">
    <img src="c2.png"width="300">
    <img src="c3.png"width="300">
    <hr>
    <h3>porcion de budines 300$</h3>
    <img src="a.png"width="300">
    <img src="budin.png"width="300">
    <hr>
    <h3>conjunto merienda(brownie con frutos rojos,cookies,rolls y pan) 1000$</h3>
    <img src="variado.png"width="300">
    
</body>
</html>