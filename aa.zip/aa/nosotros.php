<!DOCTYPE html>
<html lang="en">
<nav class="menu">

 <ul>
	<li> <a href="producto.php">Inicio </a></li>
	<li> <a href="nosotros.php">Nosotros </a></li>
	<li> <a href="contacto.php">Contacto </a></li>
 </ul>

</nav>
<head>
    <title>nosotros</title>
    </head>
<body>
   <h1>nosotros</h1>
    <p>Este emprendimiento empezo hace un año, y esta creciendo de forma agigantada .hoy en dia nos pueden encontrar en ferias de comida mayoritariamente en las que se hacen por zona norte.</p>
    <p>Hoy en dia no tenemos delivery ni un local fijo pero nuestra idea es expandirnos y poder conseguir todo esto.</p>
    <p>muchas gracias por visitar nuestra pagina. para saber en que ferias nos pueden encontrar pueden visitar nuestro instagram. </p> 
    <a target="_blank" href="https://www.instagram.com/vila.pasteleria/">vilapasteleria</a>
</body>
</html>