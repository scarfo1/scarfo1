<!DOCTYPE html>
<html lang="en">
<head>
    <title>contacto</title>
</head>
<body>
<nav class="menu">

 <ul>
	<li> <a href="producto.php">Inicio </a></li>
	<li> <a href="nosotros.php">Nosotros </a></li>
	<li> <a href="contacto.php">Contacto </a></li>
 </ul>

</nav>   
<form>
        <h1>contacto</h1>
        <label for="nombre">nombre</label>
        <input type="text" id="nombre" name="nombre" placeholder="nombre">
        <br>
        <label for="apellido">apellido</label>
        <input type="text" id="apellido" name="apellido" placeholder="apellido">
        <br>
        <textarea rows="20" cols="50" id="comentario" placeholder="ingrese comentario" name="comentario"></textarea>
    </form>
    <p>otras plataformas por las que se puede comunicar son.</p>
    <p>gmail:vilapasteleria@gmail.com</p>
    <p>o por nuestra cuenta de instagram: </p><a target="_blank" href="https://www.instagram.com/vila.pasteleria/">vilapasteleria</a>
</body>
</html>